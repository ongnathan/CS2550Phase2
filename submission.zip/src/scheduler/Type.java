package scheduler;

public enum Type {
	I, D, R, M, G;
}
