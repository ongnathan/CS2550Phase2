package data;

public class AreaCode extends PhoneNumber
{
	public AreaCode(String areaCode)
	{
		super(areaCode + "_________");
	}
}
