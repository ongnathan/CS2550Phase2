package memoryManager;

public class Page {
	
}
